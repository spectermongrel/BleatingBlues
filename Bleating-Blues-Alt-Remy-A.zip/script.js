/* VARIABLES */
let walls, player, flower1, flower2, flower3, enemy, enemy2;
let sheepimg;
let flower;
let score = 0;
let bgmusic;
let bgblock;
let happy;
let neutral;

/* PRELOAD LOADS FILES */
function preload(){
  sheepimg = loadImage("assets/sheepimg.png");
  flower = loadImage("assets/flower.png");
  bgmusic = loadSound("assets/lookyourback!.mp3");
  bgblock = loadImage("assets/bgblock.png");
  happy = loadImage("assets/happy.png");
  neutral = loadImage("assets/neutral.png");
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400,400);
  background('lightblue');
  bgmusic.play();
  
  //player
  player = new Sprite(354, 50, 40,40);
  player.img = sheepimg;
  player.rotationLock = true;
  player.rotation = 0

  //flowers
  flower1 = new Sprite(50, 50,40);
  flower1.img = flower;
  flower2 = new Sprite(360, 150 ,40);
  flower2.img = flower;
  flower3 = new Sprite(50, 360,40);
  flower3.img = flower;

  //maze itself
  walls = new Group();
  walls.color = color(0);
  walls.collider = 's';

  new walls.Sprite(200, 4, 400, 5,);
  new walls.Sprite(200, 398, 400, 5,);
  new walls.Sprite(398, 200, 5, 399,);
  new walls.Sprite(3, 200, 5, 399,);
  new walls.Sprite(360, 110, 95, 5,);
  new walls.Sprite(315, 210, 5, 200);
  new walls.Sprite(210, 300, 5, 200);
  new walls.Sprite(155, 200, 115, 5,);
  new walls.Sprite(100, 300, 5, 200);
  new walls.Sprite(155, 110, 115, 5,);
  new walls.Sprite(210, 50, 5, 115);
  new walls.Sprite(100, 50, 5, 115);



}

/* DRAW LOOP REPEATS */
function draw() {
background('lightblue');
  //score
  fill(0);
  textSize(20);
  text('flowers = ' + score, 280, 380);
  
  //movement
  if (kb.pressing("left")) {
    player.vel.x = -5;
  } else if (kb.pressing("right")) {
    player.vel.x = 5;
  } else if (kb.pressing("up")) {
    player.vel.y = -5;
  } else if (kb.pressing("down")) {
    player.vel.y = 5;
  } else {
    player.vel.x = 0;
    player.vel.y = 0;
  }
  

/* FUNCTIONS */
   background('lightblue');

    //movement
    if (kb.pressing("left")) {
      player.vel.x = -5;
    } else if (kb.pressing("right")) {
      player.vel.x = 5;
    } else if (kb.pressing("up")) {
      player.vel.y = -5;
    } else if (kb.pressing("down")) {
      player.vel.y = 5;
    } else {
      player.vel.x = 0;
      player.vel.y = 0;
    }

    //boundaries

    //touching flowers
    if (player.collides(flower1)){
      flower1.pos = {x: -100, y: -100};
      flower1.vel.x = 0;
      flower1.vel.y = 0;
      score = score + 1;
    }
    if (player.collides(flower2)){
      flower2.pos = {x: -100, y: -100};
      flower2.vel.x = 0;
      flower2.vel.y = 0;
      score = score + 1;
    }
    if (player.collides(flower3)){
      flower3.pos = {x: -100, y: -100};
      flower3.vel.x = 0;
      flower3.vel.y = 0;
      score = score + 1;
    }

  if (score == 2) {
    player.img = neutral;
  }
    

    //win, except make it so that it only happens when you get a third flower
    if (score == 3) {
      background('lightgreen');
    fill(0);
      textSize(20);
      text('Like winter, you find\nout your sadness\nis also temporary.', 100, 140);
      player.img = happy;

      //score
      fill(0);
      textSize(20);
      text('flowers = ' + score, 280, 380);
      player.vel.x = 0;
      player.vel.y = 0;
      
    }
  //score
  fill(0);
  textSize(20);
  text('flowers = ' + score, 280, 380);
}